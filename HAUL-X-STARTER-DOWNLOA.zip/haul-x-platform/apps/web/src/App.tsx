import { useMemo, useState } from 'react'
import './App.css'

type Form = { name: string; email: string; phone: string; pickup: string; delivery: string; date: string; cargo: string; packaging: string; weight: string; quantity: string; transport: string; notes: string }
const initial: Form = { name: '', email: '', phone: '', pickup: '', delivery: '', date: '', cargo: 'General goods', packaging: 'Cartons / boxes', weight: 'Under 100 kg', quantity: '1–5', transport: 'Recommend the best option', notes: '' }
const cargo = [{ icon: '📦', name: 'General goods' }, { icon: '💻', name: 'Electronics' }, { icon: '🪑', name: 'Furniture' }, { icon: '⚙️', name: 'Machinery' }, { icon: '🥫', name: 'Food products' }, { icon: '🫙', name: 'Fragile goods' }, { icon: '👕', name: 'Textiles' }, { icon: '📋', name: 'Other' }]
const transports = [{ icon: '🚛', name: 'Road', detail: 'Flexible, door-to-door movement' }, { icon: '🚆', name: 'Rail', detail: 'For larger loads over land' }, { icon: '✈️', name: 'Air', detail: 'For time-sensitive shipments' }, { icon: '🚢', name: 'Sea', detail: 'For international and bulk cargo' }, { icon: '✦', name: 'Recommend the best option', detail: 'Let our team review your requirements' }]
const packaging = ['Cartons / boxes', 'Pallets', 'Bags', 'Loose cargo', 'Other']
const weights = ['Under 100 kg', '100–500 kg', '500 kg–1 tonne', '1–5 tonnes', 'Above 5 tonnes', 'Not sure']
const quantities = ['1–5', '6–20', '21–50', 'Above 50']

function App() {
  const [form, setForm] = useState<Form>(initial)
  const [step, setStep] = useState(0)
  const [sent, setSent] = useState(false)
  const [error, setError] = useState('')
  const update = (key: keyof Form, value: string) => setForm(old => ({ ...old, [key]: value }))
  const steps = ['Cargo', 'Transport', 'Route', 'Contact', 'Review']
  const summary = useMemo(() => `${form.cargo} | ${form.packaging} | ${form.weight} | ${form.quantity} packages | ${form.transport}`, [form])
  const next = () => {
    setError('')
    if (step === 2 && (!form.pickup.trim() || !form.delivery.trim())) return setError('Please enter both pickup and delivery locations.')
    if (step === 3 && (!form.name.trim() || !/^\S+@\S+\.\S+$/.test(form.email) || !form.phone.trim())) return setError('Please enter your name, a valid email and phone number.')
    setStep(s => Math.min(4, s + 1))
  }
  const submit = () => {
    const body = `HAUL X SHIPMENT ENQUIRY\n\nName: ${form.name}\nEmail: ${form.email}\nPhone: ${form.phone}\nPickup: ${form.pickup}\nDelivery: ${form.delivery}\nPreferred date: ${form.date || 'Not specified'}\nCargo: ${form.cargo}\nPackaging: ${form.packaging}\nWeight: ${form.weight}\nQuantity: ${form.quantity}\nTransport: ${form.transport}\nAdditional notes: ${form.notes || 'None'}\n\nPlease review and respond with a quotation.`
    window.location.href = `mailto:solar.corporation.co@gmail.com?subject=${encodeURIComponent('HAUL X shipment enquiry')}&body=${encodeURIComponent(body)}`
    setSent(true)
  }
  return <div className="site-shell">
    <header className="nav"><a className="brand" href="#top"><span className="brand-mark">H</span><span>HAUL <b>X</b></span></a><a className="nav-cta" href="#quote">Get a quote <span>↗</span></a></header>
    <main id="top">
      <section className="hero">
        <div className="hero-copy"><div className="eyebrow"><span className="pulse"/> LOGISTICS · CONNECTED · FORWARD</div><h1>Move your world.<br/><em>Move it smarter.</em></h1><p>Logistics built around clarity, coordination and dependable movement. Tell us what you need to move and our team can review your request.</p><a className="primary-btn" href="#quote">Plan a shipment <span>↗</span></a><div className="hero-foot"><span>01 / A smarter way to move</span><span>BUILT TO MOVE FORWARD</span></div></div>
        <div className="visual" aria-label="Animated logistics route illustration"><div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="route-line"/><div className="route-dot dot-a"/><div className="route-dot dot-b"/><div className="cargo-scene"><div className="container c-back"/><div className="container c-front"><i/><i/><i/><i/><i/></div><div className="truck-base"/><div className="truck-wheel w1"/><div className="truck-wheel w2"/></div><div className="float-tag tag-top">↗ ROUTE PLANNING</div><div className="float-tag tag-bottom"><span className="live-dot"/> MOVING FORWARD</div></div>
      </section>
      <section className="ticker"><span>ROAD FREIGHT</span><b>✦</b><span>RAIL LOGISTICS</span><b>✦</b><span>AIR CARGO</span><b>✦</b><span>SEA FREIGHT</span><b>✦</b><span>SMARTER MOVEMENT</span></section>
      <section className="quote-section" id="quote"><div className="section-intro"><div className="eyebrow">02 / START A SHIPMENT</div><h2>Every move starts<br/><em>with a clear plan.</em></h2><p>Share a few details. Our team can review your requirements and follow up about a quotation. Submitting an enquiry does not confirm a booking.</p></div>
        <div className="form-card"><div className="form-head"><div><span className="form-kicker">SHIPMENT ENQUIRY</span><h3>{['What are you shipping?', 'Choose your transport', 'Where is it going?', 'How can we reach you?', 'Review your enquiry'][step]}</h3></div><span className="step-count">0{step + 1} / 05</span></div><div className="progress">{steps.map((s,i)=><span key={s} className={i<=step?'active':''}/>)}</div>
          {step===0 && <div className="form-content"><label className="field-label">Cargo category</label><div className="cargo-grid">{cargo.map(c=><button type="button" key={c.name} className={`choice cargo-choice ${form.cargo===c.name?'selected':''}`} onClick={()=>update('cargo',c.name)}><span>{c.icon}</span>{c.name}</button>)}</div><div className="two-fields"><label>Packaging type<select value={form.packaging} onChange={e=>update('packaging',e.target.value)}>{packaging.map(x=><option key={x}>{x}</option>)}</select></label><label>Approximate weight<select value={form.weight} onChange={e=>update('weight',e.target.value)}>{weights.map(x=><option key={x}>{x}</option>)}</select></label></div><label>Number of packages<select value={form.quantity} onChange={e=>update('quantity',e.target.value)}>{quantities.map(x=><option key={x}>{x}</option>)}</select></label></div>}
          {step===1 && <div className="form-content"><label className="field-label">Preferred transport method</label><div className="transport-list">{transports.map(t=><button type="button" key={t.name} className={`choice transport-choice ${form.transport===t.name?'selected':''}`} onClick={()=>update('transport',t.name)}><span className="transport-icon">{t.icon}</span><span className="transport-text"><b>{t.name}</b><small>{t.detail}</small></span><span className="radio-dot"/></button>)}</div></div>}
          {step===2 && <div className="form-content"><label>Pickup location<input value={form.pickup} onChange={e=>update('pickup',e.target.value)} placeholder="City, area or postal code"/></label><label>Delivery location<input value={form.delivery} onChange={e=>update('delivery',e.target.value)} placeholder="City, area or postal code"/></label><label>Preferred pickup date <span className="optional">(optional)</span><input type="date" value={form.date} onChange={e=>update('date',e.target.value)}/></label><label>Additional information <span className="optional">(optional)</span><textarea value={form.notes} onChange={e=>update('notes',e.target.value)} placeholder="Any special handling or delivery requirements?" rows={3}/></label></div>}
          {step===3 && <div className="form-content"><label>Full name<input value={form.name} onChange={e=>update('name',e.target.value)} placeholder="Your name"/></label><label>Email address<input type="email" value={form.email} onChange={e=>update('email',e.target.value)} placeholder="you@example.com"/></label><label>Phone number<input type="tel" value={form.phone} onChange={e=>update('phone',e.target.value)} placeholder="Include country code"/></label><p className="privacy-note">Your contact details will be included in your enquiry email.</p></div>}
          {step===4 && <div className="form-content review-list"><div className="review-row"><small>CARGO</small><b>{summary}</b></div><div className="review-row"><small>ROUTE</small><b>{form.pickup} → {form.delivery}</b></div><div className="review-row"><small>PREFERRED DATE</small><b>{form.date || 'Not specified'}</b></div><div className="review-row"><small>CONTACT</small><b>{form.name} · {form.email} · {form.phone}</b></div><p className="privacy-note">Selecting submit opens your email app with the enquiry details prepared. No booking is created and no payment is taken.</p></div>}
          {error && <p className="error">{error}</p>}{sent && <p className="privacy-note">Your email app should open with your enquiry. Please send the prepared email to complete the enquiry.</p>}
          <div className="form-actions">{step>0&&<button className="back-btn" type="button" onClick={()=>{setError('');setStep(s=>s-1)}}>← Back</button>}{step<4?<button className="primary-btn form-next" type="button" onClick={next}>Continue <span>→</span></button>:<button className="primary-btn form-next" type="button" onClick={submit}>Prepare enquiry <span>↗</span></button>}</div>
        </div>
      </section>
      <section className="closing"><div className="eyebrow">HAUL X · AN INITIATIVE BY SOLAR CORP.CO</div><h2>Move forward.<br/><em>With confidence.</em></h2><a href="#quote" className="primary-btn">Start an enquiry ↗</a></section>
    </main>
    <footer className="footer"><a className="brand" href="#top"><span className="brand-mark">H</span><span>HAUL <b>X</b></span></a><span>AN INITIATIVE BY SOLAR CORP.CO</span><small>© 2026 HAUL X</small><a href="mailto:solar.corporation.co@gmail.com">solar.corporation.co@gmail.com ↗</a></footer>
  </div>
}
export default App
